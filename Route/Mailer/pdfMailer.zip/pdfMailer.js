const nodemailer = require("nodemailer");

// Function to convert some content to PDF (replace this with your actual conversion logic)
function convertToPdf(content) {
  // Replace this with your actual conversion logic
  // Assume this function returns a Buffer containing PDF content
  const pdfContent = Buffer.from(content, "utf-8");
  return pdfContent;
}

// Function to send an email with the PDF attachment
async function sendEmailWithPdf(myObj, pdfContent) {
  const transporter = nodemailer.createTransport({
    host: myObj.SmtpHost,
    port: myObj.SmtpPort,
    secure: false, // true for 465, false for other ports
    auth: {
      user: myObj.SmtpMail,
      pass: myObj.AppPassword,
    },
    [myObj.SmtpSecure === 'tls' ? 'tls' : 'ssl']: {
      rejectUnauthorized: false,
    },
  });

  const mailOptions = {
    from: myObj.SmtpMail,
    to: myObj.emailClient,
    subject: "PDF Attachment",
    html: generateHtmlTemplate(myObj),
    text: `Hello ${myObj.nameClient},\nPlease find the attached PDF.`,
    attachments: [
      {
        filename: "document.pdf",
        content: pdfContent.toString("base64"),
        encoding: "base64",
      },
    ],
  };

  return new Promise((resolve, reject) => {
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        reject(error);
      } else {
        resolve(info);
      }
    });
  });
}

// Example route to handle the PDF content and send the email
MyRouter.post("/SendEmailWithPdf", async (req, res) => {
  // Get the content to convert to PDF from the request body
  const contentToConvert = req.body.content;

  // Convert the content to PDF
  const pdfContent = convertToPdf(contentToConvert);

  // Send the email with the PDF attachment
  try {
    await sendEmailWithPdf(req.body, pdfContent);
    res.send("Email sent successfully!");
  } catch (error) {
    console.error(error);
    res.status(500).send("Error sending email");
  }
});

module.exports = MyRouter;
